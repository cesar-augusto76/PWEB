function Operacoes()
{
    let numero1 = document.querySelector('input[name="numero1"]').value;
    let numero2 = document.querySelector('input[name="numero2"]').value;

     numero1 = parseFloat(numero1.replace(',', '.'));
     numero2 = parseFloat(numero2.replace(',', '.'));

     let soma = numero1 + numero2;
     let subtracao = numero1 - numero2;
     let divisao = numero1/numero2;
     let multiplicacao = numero1 * numero2;
     let resto = numero1 % numero2;

     alert("Soma: " + soma);
     alert("Subtracao: " + subtracao);
     alert("Multiplicacao: " + multiplicacao);
     alert("Divisao: " + divisao);
     alert("Resto da divisao: " + resto);
}
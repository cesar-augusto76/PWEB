function Media(){
    const nome = document.querySelector('input[name="nome"]').value;

    let valor1 = document.querySelector('input[name="nota1"]').value;
    let valor2 = document.querySelector('input[name="nota2"]').value;
    let valor3 = document.querySelector('input[name="nota3"]').value;
    let valor4 = document.querySelector('input[name="nota4"]').value;

    let nota1 = parseFloat(valor1.replace(',', '.'));
    let nota2 = parseFloat(valor2.replace(',', '.'));
    let nota3 = parseFloat(valor3.replace(',', '.'));
    let nota4 = parseFloat(valor4.replace(',', '.'));

    
    if (isNaN(nota1) || isNaN(nota2) || isNaN(nota3) || isNaN(nota4)) {
        alert("Por favor, preencha todas as quatro notas com números válidos!");
        return;
    }

    let media = (nota1 + nota2 + nota3 + nota4) / 4;

    
    alert("O aluno " + nome + " tem média " + media.toFixed(2));
}






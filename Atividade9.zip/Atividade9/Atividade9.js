    function ReceberMaior() {
  const num1 = Number(prompt("Insira o primeiro número:"));
  const num2 = Number(prompt("Insira o segundo número:"));
  const num3 = Number(prompt("Insira o terceiro número:"));
  
  let maior;
  if (num1 >= num2 && num1 >= num3) {
    maior = num1;
  } else if (num2 >= num1 && num2 >= num3) {
    maior = num2;
  } else {
    maior = num3;
  }
  
  alert("O maior valor é: " + maior);
}
        
    function OrdemCrescente() 
{
  const numero1 = Number(prompt("Insira um número:"));
  const numero2 = Number(prompt("Insira outro número:"));
  const numero3 = Number(prompt("Insira o último valor:"));
  
  const numeros = [numero1, numero2, numero3];
  numeros.sort((a, b) => a - b);
  
  alert("A ordem crescente dos números inseridos é: " + numeros.join(", "));
}
        
        function Palindromo()
        {
            let palavra = prompt("Insira uma palavra: ");
            const palavraOriginal = palavra.toLowerCase().replace(/[^a-z0-9]/g, "");
            const palavraInvertida = palavraOriginal.split('').reverse().join("");

            if (palavraOriginal === palavraInvertida)
            {
                return "É um palíndromo!";
            }
            else
            {
                return "Não é um palíndromo!";
            }
        }
        
       function erroOUundefined() 
       {
        const texto1 = prompt("Insira uma palavra:");
        const texto2 = prompt("Insira outra palavra:");

        if ((texto1 === "" || texto1 === null) && (texto2 === "" || texto2 === null)) 
            {
            return "Erro";
            } 
            else if (!texto1 || !texto2) 
            {
            return "Não é um subconjunto";
            } 
            else if (texto1.includes(texto2) || texto2.includes(texto1)) 
            {
            return "É um subconjunto";
            } 
  else 
    {
    return "Não é um subconjunto";
    }
}

        

        function DiaSemana() 
        {
            const dataStr = prompt("Digite uma data (formato DD/MM/YYYY)");
            if (!dataStr) return;

            const partes = dataStr.split('/');
            const diaNum = Number(partes[0]);
            const mesNum = Number(partes[1]) - 1;
            const anoNum = Number(partes[2]);

            const dataObj = new Date(anoNum, mesNum, diaNum);
            const diasDaSemana = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
  
            const diaSemanaIndex = dataObj.getDay();
            alert("O dia da semana da sua data é: " + diasDaSemana[diaSemanaIndex]);
        }
    

resposta1 = prompt("Jogador 1, faça a sua jogada: ");
alert("A máquina está fazendo sua jogada...");
const opcoes = ["pedra", "papel", "tesoura"];
resposta2 = opcoes[Math.floor(Math.random ()* opcoes.length)];
alert("A máquina escolheu: " + resposta2);

if (resposta1 == "pedra" && resposta2 == "pedra")
{
    alert("Empate!");
}
else if (resposta1 == "pedra" && resposta2 == "tesoura")
{
    alert("Vitória do jogador 1!");
}
else if (resposta1 == "pedra" && resposta2 == "papel")
{
    alert ("Vitória da máquina!");
}
else if (resposta1 == "papel" && resposta2 == "papel")
{
    alert("Empate!");
}
else if (resposta1 == "papel" && resposta2 == "pedra")
{
    alert("Vitória do jogador 1!");
}
else if (resposta1 == "papel" && resposta2 == "tesoura")
{
    alert("Vitória da máquina!");
}
else if (resposta1 == "tesoura" && resposta2 == "tesoura")
{
    alert("Empate!");
}
else if (resposta1 == "tesoura" && resposta2 == "pedra")
{
    alert ("Vitória da máquina!");
}
else if (resposta1 == "tesoura" && resposta2 == "papel")
{
    alert ("Vitória do jogador 1!");
}
else
    alert("Escolha uma opção valida!");